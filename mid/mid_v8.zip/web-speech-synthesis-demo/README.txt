A Pen created at CodePen.io. You can find this one at https://codepen.io/matt-west/pen/wGzuJ.

 A basic use of web speech synthesis.

Support in Chrome Canary/Dev Channel and Safari